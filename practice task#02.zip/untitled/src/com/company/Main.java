package com.company;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import static java.lang.System.*;

public class Main {
    public static  void main(String[] args) {

        File myFile = new File("CWH_file1.txt");
        Scanner input = null;
        try {
          /*  myFile.createNewFile();
            System.out.println("File created successfully.");*/
           /* FileWriter fileWriter = new FileWriter("CWH_file1.txt");
            fileWriter.write("Enter the numbers from10 to 0");
            fileWriter.close();*/
           input = new Scanner(myFile);

            while(input.hasNextLine()){
                String line =input.nextLine();
                out.println(line);

                int sum= 0;
                out.println("The total sum is: " + sum );
            
            } //finally {
                if (input != null) {
                    input.close();
            }
            input.close();
        } catch (IOException e) {
            e.printStackTrace();

        }
    }

}